﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Childrens_Educators
    {
        public Guid Id { get; set; }
        public string First_Name{ get; set; }
        public string Last_Name{ get; set; }
        public string Identity_number{ get; set; }
        public string Contact_Address{ get; set; }
        public string Contact_Telephone { get; set; }
        public string Contact_email { get; set; }
        public DateTime At_Work_Since{ get; set; }
        public DateTime At_Work_Till { get; set; }
        public string Load_capacity{ get; set; }
        public string Comment{ get; set; }
        public ICollection<Children> Childrens { get; set; }
        public ICollection<Occupations> Occupationss { get; set; }
    }
}
