﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Ressources
    {
        public Guid Id { get; set; }
        public int Ammount_Of_Food { get; set; }
        public string Food_Perseverance { get; set; }
        public string Food_Type { get; set; }
        public string Teaching_Material { get; set; }
        public string Comments { get; set; }
    }
}
