﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Kindergarten
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public string Contact_Address { get; set; }
        public string Contact_Telephone { get; set; }
        public string Contact_email { get; set; }
        public string Directors_Name { get; set; }
        public ICollection<Childrens_Educators> Childrens_Educatorss { get; set; }
        public ICollection<Children> Childrens { get; set; }
        public string Comment { get; set; }
    }
}
