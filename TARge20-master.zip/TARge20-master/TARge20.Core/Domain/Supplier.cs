﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Supplier
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Ammount { get; set; }
        public string Comment { get; set; }
        public ICollection<Ressources> Ressourcess { get; set; }
    }
}
