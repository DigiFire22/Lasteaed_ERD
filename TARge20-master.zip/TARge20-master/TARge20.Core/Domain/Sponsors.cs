﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Sponsors
    {
        public Guid ID { get; set; }
        public int payment { get; set; }
        public string requerments { get; set; }
        public string comments { get; set; }
        public ICollection<Kindergarten> Kindergartens { get; set; }
        public ICollection<Supplier> Suppliers { get; set; }
    }
}
