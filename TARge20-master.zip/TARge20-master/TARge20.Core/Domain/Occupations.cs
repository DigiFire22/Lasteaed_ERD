﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Occupations
    {
        public Guid Id { get; set; }
        public string Occupation_Name { get; set; }
        public string Assignement { get; set; }
        public string Comment { get; set; }
        public ICollection<Children> Childrens { get; set; }
        public ICollection<Child_Groups> Child_Groupss { get; set; }
        public ICollection<Kindergarten> kindergartenss { get; set; }
        public ICollection<Ressources> Ressourcess { get; set; }
    }
}
