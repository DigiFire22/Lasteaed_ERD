﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Work_History
    {
        public Guid Id { get; set; }
        public string Previous_Educator_Job { get; set; }
        public string Comments { get; set; }
        public ICollection<Childrens_Educators> Childrens_Educatorss { get; set; }
    }
}
