﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Diffrence
    {
        public Guid Id { get; set; }
        public string Element { get; set; }
        public string Comment { get; set; }
        public ICollection<Child_Groups> child_Groupss { get; set; }
    }
}
