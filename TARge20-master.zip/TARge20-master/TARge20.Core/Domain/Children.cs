﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Children
    {
        public Guid Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Guardian_Contact_Information { get; set; }
        public DateTime When_They_Come { get; set; }
        public DateTime When_They_Leave { get; set; }
        public int Childs_Age { get; set; }
        public string Comment { get; set; }
        public ICollection<Child_Groups> Child_Groupss { get; set; }
        public ICollection<Ressources> Ressourcess { get; set; }
        public ICollection<Diffrence> Types { get; set; }
    }
}
