﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Child_Groups
    {
        public Guid Id { get; set; }
        public string Groups_Name { get; set; }
        public int Amount_Of_Children { get; set; }
        public string Comments { get; set; }
        public ICollection<Ressources> Ressourcess { get; set; }
        public ICollection<Kindergarten> kindergartenss { get; set; }
    }
}
