﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class Migrations : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "sponsors",
                columns: table => new
                {
                    ID = table.Column<Guid>(nullable: false),
                    payment = table.Column<int>(nullable: false),
                    requerments = table.Column<string>(nullable: true),
                    comments = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sponsors", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Work_Historiess",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Previous_Educator_Job = table.Column<string>(nullable: true),
                    Comments = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Work_Historiess", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "supplierss",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Ammount = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    SponsorsID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_supplierss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_supplierss_sponsors_SponsorsID",
                        column: x => x.SponsorsID,
                        principalTable: "sponsors",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "kindergartens",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Location = table.Column<string>(nullable: true),
                    Contact_Address = table.Column<string>(nullable: true),
                    Contact_Telephone = table.Column<string>(nullable: true),
                    Contact_email = table.Column<string>(nullable: true),
                    Directors_Name = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    Child_GroupsId = table.Column<Guid>(nullable: true),
                    OccupationsId = table.Column<Guid>(nullable: true),
                    SponsorsID = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_kindergartens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_kindergartens_sponsors_SponsorsID",
                        column: x => x.SponsorsID,
                        principalTable: "sponsors",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "childrens_Educatorss",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    First_Name = table.Column<string>(nullable: true),
                    Last_Name = table.Column<string>(nullable: true),
                    Identity_number = table.Column<string>(nullable: true),
                    Contact_Address = table.Column<string>(nullable: true),
                    Contact_Telephone = table.Column<string>(nullable: true),
                    Contact_email = table.Column<string>(nullable: true),
                    At_Work_Since = table.Column<DateTime>(nullable: false),
                    At_Work_Till = table.Column<DateTime>(nullable: false),
                    Load_capacity = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    KindergartenId = table.Column<Guid>(nullable: true),
                    Work_HistoryId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_childrens_Educatorss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_childrens_Educatorss_kindergartens_KindergartenId",
                        column: x => x.KindergartenId,
                        principalTable: "kindergartens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_childrens_Educatorss_Work_Historiess_Work_HistoryId",
                        column: x => x.Work_HistoryId,
                        principalTable: "Work_Historiess",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "occupationss",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Occupation_Name = table.Column<string>(nullable: true),
                    Assignement = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    Childrens_EducatorsId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_occupationss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_occupationss_childrens_Educatorss_Childrens_EducatorsId",
                        column: x => x.Childrens_EducatorsId,
                        principalTable: "childrens_Educatorss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Childrens",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    First_Name = table.Column<string>(nullable: true),
                    Last_Name = table.Column<string>(nullable: true),
                    Guardian_Contact_Information = table.Column<string>(nullable: true),
                    When_They_Come = table.Column<DateTime>(nullable: false),
                    When_They_Leave = table.Column<DateTime>(nullable: false),
                    Childs_Age = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    Childrens_EducatorsId = table.Column<Guid>(nullable: true),
                    KindergartenId = table.Column<Guid>(nullable: true),
                    OccupationsId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Childrens", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Childrens_childrens_Educatorss_Childrens_EducatorsId",
                        column: x => x.Childrens_EducatorsId,
                        principalTable: "childrens_Educatorss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Childrens_kindergartens_KindergartenId",
                        column: x => x.KindergartenId,
                        principalTable: "kindergartens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Childrens_occupationss_OccupationsId",
                        column: x => x.OccupationsId,
                        principalTable: "occupationss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Diffrencess",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Element = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    ChildrenId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Diffrencess", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Diffrencess_Childrens_ChildrenId",
                        column: x => x.ChildrenId,
                        principalTable: "Childrens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "child_Groupss",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Groups_Name = table.Column<string>(nullable: true),
                    Amount_Of_Children = table.Column<int>(nullable: false),
                    Comments = table.Column<string>(nullable: true),
                    ChildrenId = table.Column<Guid>(nullable: true),
                    DiffrenceId = table.Column<Guid>(nullable: true),
                    OccupationsId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_child_Groupss", x => x.Id);
                    table.ForeignKey(
                        name: "FK_child_Groupss_Childrens_ChildrenId",
                        column: x => x.ChildrenId,
                        principalTable: "Childrens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_child_Groupss_Diffrencess_DiffrenceId",
                        column: x => x.DiffrenceId,
                        principalTable: "Diffrencess",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_child_Groupss_occupationss_OccupationsId",
                        column: x => x.OccupationsId,
                        principalTable: "occupationss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Ressourcess",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Ammount_Of_Food = table.Column<int>(nullable: false),
                    Food_Perseverance = table.Column<string>(nullable: true),
                    Food_Type = table.Column<string>(nullable: true),
                    Teaching_Material = table.Column<string>(nullable: true),
                    Comments = table.Column<string>(nullable: true),
                    Child_GroupsId = table.Column<Guid>(nullable: true),
                    ChildrenId = table.Column<Guid>(nullable: true),
                    OccupationsId = table.Column<Guid>(nullable: true),
                    SupplierId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ressourcess", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Ressourcess_child_Groupss_Child_GroupsId",
                        column: x => x.Child_GroupsId,
                        principalTable: "child_Groupss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Ressourcess_Childrens_ChildrenId",
                        column: x => x.ChildrenId,
                        principalTable: "Childrens",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Ressourcess_occupationss_OccupationsId",
                        column: x => x.OccupationsId,
                        principalTable: "occupationss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Ressourcess_supplierss_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "supplierss",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_child_Groupss_ChildrenId",
                table: "child_Groupss",
                column: "ChildrenId");

            migrationBuilder.CreateIndex(
                name: "IX_child_Groupss_DiffrenceId",
                table: "child_Groupss",
                column: "DiffrenceId");

            migrationBuilder.CreateIndex(
                name: "IX_child_Groupss_OccupationsId",
                table: "child_Groupss",
                column: "OccupationsId");

            migrationBuilder.CreateIndex(
                name: "IX_Childrens_Childrens_EducatorsId",
                table: "Childrens",
                column: "Childrens_EducatorsId");

            migrationBuilder.CreateIndex(
                name: "IX_Childrens_KindergartenId",
                table: "Childrens",
                column: "KindergartenId");

            migrationBuilder.CreateIndex(
                name: "IX_Childrens_OccupationsId",
                table: "Childrens",
                column: "OccupationsId");

            migrationBuilder.CreateIndex(
                name: "IX_childrens_Educatorss_KindergartenId",
                table: "childrens_Educatorss",
                column: "KindergartenId");

            migrationBuilder.CreateIndex(
                name: "IX_childrens_Educatorss_Work_HistoryId",
                table: "childrens_Educatorss",
                column: "Work_HistoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Diffrencess_ChildrenId",
                table: "Diffrencess",
                column: "ChildrenId");

            migrationBuilder.CreateIndex(
                name: "IX_kindergartens_Child_GroupsId",
                table: "kindergartens",
                column: "Child_GroupsId");

            migrationBuilder.CreateIndex(
                name: "IX_kindergartens_OccupationsId",
                table: "kindergartens",
                column: "OccupationsId");

            migrationBuilder.CreateIndex(
                name: "IX_kindergartens_SponsorsID",
                table: "kindergartens",
                column: "SponsorsID");

            migrationBuilder.CreateIndex(
                name: "IX_occupationss_Childrens_EducatorsId",
                table: "occupationss",
                column: "Childrens_EducatorsId");

            migrationBuilder.CreateIndex(
                name: "IX_Ressourcess_Child_GroupsId",
                table: "Ressourcess",
                column: "Child_GroupsId");

            migrationBuilder.CreateIndex(
                name: "IX_Ressourcess_ChildrenId",
                table: "Ressourcess",
                column: "ChildrenId");

            migrationBuilder.CreateIndex(
                name: "IX_Ressourcess_OccupationsId",
                table: "Ressourcess",
                column: "OccupationsId");

            migrationBuilder.CreateIndex(
                name: "IX_Ressourcess_SupplierId",
                table: "Ressourcess",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_supplierss_SponsorsID",
                table: "supplierss",
                column: "SponsorsID");

            migrationBuilder.AddForeignKey(
                name: "FK_kindergartens_occupationss_OccupationsId",
                table: "kindergartens",
                column: "OccupationsId",
                principalTable: "occupationss",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_kindergartens_child_Groupss_Child_GroupsId",
                table: "kindergartens",
                column: "Child_GroupsId",
                principalTable: "child_Groupss",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_child_Groupss_Childrens_ChildrenId",
                table: "child_Groupss");

            migrationBuilder.DropForeignKey(
                name: "FK_Diffrencess_Childrens_ChildrenId",
                table: "Diffrencess");

            migrationBuilder.DropForeignKey(
                name: "FK_child_Groupss_Diffrencess_DiffrenceId",
                table: "child_Groupss");

            migrationBuilder.DropForeignKey(
                name: "FK_child_Groupss_occupationss_OccupationsId",
                table: "child_Groupss");

            migrationBuilder.DropForeignKey(
                name: "FK_kindergartens_occupationss_OccupationsId",
                table: "kindergartens");

            migrationBuilder.DropTable(
                name: "Ressourcess");

            migrationBuilder.DropTable(
                name: "supplierss");

            migrationBuilder.DropTable(
                name: "Childrens");

            migrationBuilder.DropTable(
                name: "Diffrencess");

            migrationBuilder.DropTable(
                name: "occupationss");

            migrationBuilder.DropTable(
                name: "childrens_Educatorss");

            migrationBuilder.DropTable(
                name: "kindergartens");

            migrationBuilder.DropTable(
                name: "Work_Historiess");

            migrationBuilder.DropTable(
                name: "child_Groupss");

            migrationBuilder.DropTable(
                name: "sponsors");
        }
    }
}
