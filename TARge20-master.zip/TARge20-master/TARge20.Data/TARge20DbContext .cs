﻿// using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TARge20.Core.Domain;

namespace TARge20.Data
{
    public class TARge20DbContext : DbContext
    {

        public TARge20DbContext(DbContextOptions<TARge20DbContext> options)
            : base(options) { }
        
        // näide, kuidas teha, kui lisate domaini alla ühe objekti
        // migratsioonid peavad tulema siia libary-sse e TARge20.Data alla.
        public DbSet<Children> Childrens { get; set; }
        public DbSet<Childrens_Educators> childrens_Educatorss { get; set; }
        public DbSet<Child_Groups> child_Groupss { get; set; }
        public DbSet<Kindergarten> kindergartens { get; set; }
        public DbSet<Occupations> occupationss { get; set; }
        public DbSet<Ressources> Ressourcess { get; set; }
        public DbSet<Diffrence> Diffrencess { get; set; }
        public DbSet<Supplier> supplierss { get; set; }
        public DbSet<Sponsors> sponsors { get; set; }
        public DbSet<Work_History> Work_Historiess { get; set; }
    }
}